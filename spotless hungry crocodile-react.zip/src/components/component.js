import React from 'react'

import PropTypes from 'prop-types'

import './component.css'

const AppComponent = (props) => {
  return (
    <div className="app-component-container">
      <span className="overline">
        <span>Pricing</span>
        <br></br>
      </span>
      <h2 className="heading2">{props.pricingHeading}</h2>
      <span className="app-component-pricing-sub-heading bodyLarge">
        <span>
          <span>
            Unlock the full potential of your media management and advertisement
            strategies with our tailored plans.
          </span>
        </span>
      </span>
    </div>
  )
}

AppComponent.defaultProps = {
  pricingHeading: 'Choose the Right Plan for Your Business',
}

AppComponent.propTypes = {
  pricingHeading: PropTypes.string,
}

export default AppComponent
